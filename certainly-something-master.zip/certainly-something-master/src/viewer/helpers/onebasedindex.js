export default (index) => {
  return index + 1;
};
