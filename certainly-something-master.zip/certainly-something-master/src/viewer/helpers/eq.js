export default (i, j) => {
  // explicitly not === for template usage
  return i == j;
};
